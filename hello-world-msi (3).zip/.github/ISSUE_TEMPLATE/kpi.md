---
name: 📊 KPI
about: Criar um novo indicador chave de desempenho
---

## 📊 KPI
**Título:** 

### Objetivo
Descreva o que está sendo medido e por quê.

### Indicador
✅ Indicador definido

### Meta
🎯 Meta clara e objetiva

### Frequência de medição
Ex: Semanal, mensal

### Responsável
@nome_usuario
