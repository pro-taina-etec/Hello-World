---
name: 🎯 OKR
about: Adicionar um novo objetivo com resultados-chave
---

## 🎯 OKR
**Objetivo:** 

### Resultados-chave
- [ ] KR1
- [ ] KR2
- [ ] KR3

### Responsável
@nome_usuario
