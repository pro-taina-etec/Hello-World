---
name: 🧩 Tarefa
about: Criar uma nova tarefa
---

## 📝 Tarefa
**Título:** 

### Objetivo
Descreva o que será feito.

### Checklist
- [ ] Passo 1
- [ ] Passo 2

### Responsável
@nome_usuario

### Prazo
`AAAA-MM-DD`
