---
name: 🧱 Débito Técnico
about: Registrar uma dívida técnica identificada
---

## 🧱 Débito Técnico
**Título:** 

### Contexto
Descrever o problema ou limitação técnica atual.

### Impacto
Explicar como afeta o projeto.

### Solução proposta
Sugestão de correção.

### Responsável
@nome_usuario

### Prioridade
Alta | Média | Baixa
