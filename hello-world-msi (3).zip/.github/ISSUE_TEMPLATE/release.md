---
name: 🚀 Release
about: Documentar uma nova entrega de versão
---

## 🚀 Release
**Título da Release:** 

### Conteúdo da Release
- [ ] Feature 1
- [ ] Correção 2

### Alterações
Liste aqui as mudanças feitas.

### Data da release
`AAAA-MM-DD`
