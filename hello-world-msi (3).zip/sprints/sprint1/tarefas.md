# ✅ Tarefas da Sprint 1

- [ ] Definir missão
- [ ] Montar equipe
