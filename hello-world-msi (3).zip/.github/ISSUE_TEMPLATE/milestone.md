---
name: 🎯 Milestone
about: Definir uma etapa ou marco importante
---

## 🎯 Milestone
**Título do Marco:** 

### Descrição
Descrever a importância dessa etapa.

### Tarefas relacionadas
- [ ] Tarefa 1
- [ ] Tarefa 2

### Data-alvo
`AAAA-MM-DD`
