---
name: 🌟 Funcionalidade
about: Sugestão de nova funcionalidade
---

## 🌟 Funcionalidade
**Título:** 

### Descrição
Descreva a funcionalidade a ser implementada.

### Critérios de aceite
- [ ] Deve fazer X
- [ ] Deve permitir Y

### Responsável
@nome_usuario

### Data estimada de entrega
`AAAA-MM-DD`
