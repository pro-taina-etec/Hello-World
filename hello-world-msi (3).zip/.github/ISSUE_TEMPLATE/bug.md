---
name: 🐛 Bug
about: Reportar um erro ou comportamento inesperado
---

## 🐛 Bug
**Título:** 

### Descrição
Descreva o problema encontrado.

### Passos para reproduzir
1. 
2. 
3. 

### Comportamento esperado
Descreva o que deveria acontecer.

### Evidências
(prints, vídeos, logs)

### Responsável
@nome_usuario

### Prioridade
Alta | Média | Baixa
