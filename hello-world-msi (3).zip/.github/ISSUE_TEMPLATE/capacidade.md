---
name: 🔍 Capacidade
about: Descrever uma habilidade ou competência a ser desenvolvida
---

## 🔍 Capacidade
**Título:** 

### Objetivo
Explicar a habilidade técnica ou comportamental esperada.

### Requisitos
- [ ] Requisito 1
- [ ] Requisito 2

### Indicadores de sucesso
✅ Descrição do indicador

### Responsável
@nome_usuario
