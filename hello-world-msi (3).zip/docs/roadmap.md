# 🗺️ Roadmap do Projeto

Este documento descreve o plano de execução em 6 meses.
